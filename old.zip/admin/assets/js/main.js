jQuery(function(t){
    "use strict"

});